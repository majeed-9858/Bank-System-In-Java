package academics;

public class Teacher {

	private String tName;

//Constructor
public Teacher(){
	tName = " ";
}

//Overloaded Constructor
public Teacher(String tName) {
	this.tName = tName;
}

//Setters And Getters

public void settName(String tName) {
	this.tName = tName;
}

public String gettName() {
	return tName;
}

@Override
public String toString() {
	return "Teacher [tName=" + tName + "]";
}
}
