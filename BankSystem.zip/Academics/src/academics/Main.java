package academics;

import java.util.Scanner;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("****************Enter Teacher Name******************");
        String tName = sc.nextLine();
        System.out.println("****************Enter Department Name:**************");
        String dname = sc.nextLine();

        Teacher t1 = new Teacher(tName);
        Teacher t2 = new Teacher("Sir Asif");
        Teacher t3 = new Teacher("Sir Aftab");
        Teacher t4 = new Teacher("Sir Mohsin");
        Teacher t5 = new Teacher("Sir Suleman");

        ArrayList<Teacher> teachers = new ArrayList<>();

        teachers.add(t1);
        teachers.add(t2);
        teachers.add(t3);
        teachers.add(t4);
        teachers.add(t5);

        System.out.println(teachers.get(1).gettName());
    }
}