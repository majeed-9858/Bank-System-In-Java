package academics;
import java.util.ArrayList;

public class Department {

	private String dName;
	ArrayList<Teacher> teachers;

//Default Constructor
public Department() {
	this.dName = " ";
	this.teachers = new ArrayList();
}
//Overloaded Constructor
public Department(String n) {
	this.dName = n;
}

//Setters and Getters 

public void setdName(String dName) {
	this.dName = dName;
}

public String dName() {
	return dName;
}
@Override
public String toString() {
	return "Department [dName=" + dName + ", teachers=" + teachers + "]";
}

public void addTeacher(Teacher t){
	teachers.add(t);
}
}